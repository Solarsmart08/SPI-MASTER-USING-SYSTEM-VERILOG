echo "    SPI LINUX VERIFICATION  "

echo ""
echo "[1] compiling RTL and TB..."
iverilog -g2012 \
-o sim/spi_sim \
rtl/SPI.sv \
tb/SPI_TB.sv

if [$? -ne 0]; then 
echo " COMPILATION FAILED "
exit 1
fi 
echo "COMPILATION SUCCESSFUL"
echo "[2] running simulation..."
vvp sim/spi_sim | tee results/regression.log 
if [${PIPESTATUS[0]} -ne 0]; then
echo ""
echo "simulation failed"
exit 1
fi

echo "Regression complete"

echo "simulation log:"
echo "rsult/regression.log"

echo "waveform:"
echo "sim/spi.vcd"
